Hicimos modificaciones al esquema para poder realizar una de las funciones
y, consecuentemente, un trigger. Tambien creamos el archivo Payments.sql. 
de ahi que se incluya con Scheme.sql. El archivo de la práctica es 
Practica5_Equipo01.sql. 

Atte: Equipo01
